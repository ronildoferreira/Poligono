
package aulas;


abstract public class Poligono {
    protected  int numerodeLados;

    public Poligono(int numerodeLados) {
        this.numerodeLados = numerodeLados;
    }

    public int getNumerodeLados() {
        return numerodeLados;
    }

    @Override
    public String toString() {
        return  "Número de Lados= " + numerodeLados;
    }
    
    
    public abstract  double area();
   
}
