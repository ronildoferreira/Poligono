package aulas;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    static ArrayList<Poligono> poligono = new ArrayList<Poligono>();
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        preencherPoligono();
        mostrarResultados();

    }

    public static void preencherPoligono() {
        char resposta;
        int opcao;
        do {

            do {
                System.out.println("Digite qual polígono deseja");
                System.out.println("1. Triangulo");
                System.out.println("2. Retângulo");
                System.out.println("Opção: ");
                opcao = entrada.nextInt();

            } while(opcao<1 || opcao>2);
            
            switch(opcao){
                case 1: preencherTriangulo();
                    break;
                case 2: preencherRetangulo();
                    break;
            }
            
            System.out.println("\nDeseja digitar outro Polígono(s/n) : ");
            resposta = entrada.next().charAt(0);
            System.out.println("");
             
            
        }while(resposta=='s' || resposta=='S');        
            
        }


    public static void preencherTriangulo() {
        double lado1,lado2,lado3;
        System.out.println("\nDigite o lado1 do Triângulo: ");
        lado1 = entrada.nextDouble();
        System.out.println("Digite o lado2 do Triângulo: ");
        lado2 = entrada.nextDouble();
        System.out.println("Digite o lado3 do Triângulo: ");
        lado3 = entrada.nextDouble();
        
        
        Triangulo triangulo  = new Triangulo(lado1, lado2, lado3);
        
        // Guardamos aqui um triangulo 
        poligono.add(triangulo);
    }
    
    public static void preencherRetangulo(){
        double lado1,lado2;
        
        System.out.println("\nDigite o lado1 do Retângulo: ");
        lado1 = entrada.nextDouble();
        System.out.println("Digite o lado2 do Retângulo: ");
        lado2 = entrada.nextDouble();
        
        Retangulo retangulo  = new Retangulo(lado1, lado2);
        
        poligono.add(retangulo);
        
    }
    
        public static void mostrarResultados(){
            
           // Arranjo do polígono
            
            for(Poligono poli: poligono) {
                System.out.println(poli.toString());
                System.out.println("Área= "+poli.area());
                System.out.println("");
            }
        }
    }
